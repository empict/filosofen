<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>@yield('title', 'Filosofen')</title>
    @vite('resources/css/app.css')
    <!-- Voeg hier je CSS-bestanden toe -->
</head>
<body class="min-h-screen bg-cover bg-no-repeat" style="background-image: url('{{ asset('images/background.avif') }}');">
<header>
    <nav>
        <!-- Navigatie -->

    </nav>
</header>

<main class="flex items-center justify-center h-full">
    <div class="bg-white bg-opacity-75 p-6 rounded-lg shadow-lg w-3/4 mt-4">
        @yield('content') <!-- Hier wordt de specifieke inhoud van je views geplaatst -->
    </div>
</main>

<footer class="text-center p-4 fixed bottom-0 w-full">
    <!-- Voettekst -->
    <p>&copy; {{ date('Y') }} Mijn Project</p>
</footer>
</body>
</html>
