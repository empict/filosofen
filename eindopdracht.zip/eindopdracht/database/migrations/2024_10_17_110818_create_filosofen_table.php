<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateFilosofenTable extends Migration
{
    public function up()
    {
        Schema::create('filosofen', function (Blueprint $table) {
            $table->id();
            $table->string('name');
            $table->string('country');
            $table->string('birthdate'); // Wijzig dit naar string
            $table->text('bio');
            $table->timestamps();
        });
    }

    public function down()
    {
        Schema::dropIfExists('filosofen');
    }
}
