<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AddColumnsToFilosofenTable extends Migration
{
    /**
     * Run the migrations.
     */
    public function up()
    {
        Schema::table('filosofen', function (Blueprint $table) {
            // Voeg de kolommen toe met nullable als ze optioneel zijn
            $table->string('country')->nullable();  // Land van de filosoof
            $table->date('birthdate')->nullable();  // Geboortedatum van de filosoof
            $table->text('bio')->nullable();         // Biografie van de filosoof
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down()
    {
        Schema::table('filosofen', function (Blueprint $table) {
            // Verwijder de kolommen als de migratie wordt teruggedraaid
            $table->dropColumn(['country', 'birthdate', 'bio']);
        });
    }
}
