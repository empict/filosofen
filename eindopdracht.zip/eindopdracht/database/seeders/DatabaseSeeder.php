<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    /**
     * Seed the application's database.
     */
    public function run()
    {
        // Roep de seeder aan om de filosofen in te voeren
        $this->call(PhilosopherSeeder::class);

        // Voeg hier andere seeders toe indien nodig, bijvoorbeeld:
        // $this->call(UserSeeder::class);
        // $this->call(AnotherSeeder::class);
    }
}
