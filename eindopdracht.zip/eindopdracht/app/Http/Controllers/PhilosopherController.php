<?php

namespace App\Http\Controllers;

use App\Models\Philosopher;
use Illuminate\Http\Request;

class PhilosopherController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $filosofen = Philosopher::all(); // or however you're fetching philosophers
        return view('homepage', compact('filosofen'));
    }

    public function informatie($id)
    {
        // Retrieve the philosopher by ID
        $filosoof = Philosopher::findOrFail($id);

        // Return the view with the philosopher's information
        return view('filosoof-informatie', compact('filosoof'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create(): \Illuminate\View\View // Return type declaration toegevoegd
    {
        return view('create-filosoof'); // Zorg ervoor dat dit overeenkomt met je view-bestand
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'country' => 'required|string|max:255',
            'birthdate' => 'required|string|max:255', // Geen datumnotatie validatie meer
            'bio' => 'nullable|string',
        ]);

        Philosopher::create($request->all());

        return redirect()->route('filosofen.index')->with('success', 'Filosoof toegevoegd!');
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        $filosoof = Philosopher::findOrFail($id); // Haal de filosoof op met het gegeven ID
        return view('filosoof-informatie', compact('filosoof')); // Geef de filosoof door aan de view
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        $filosoof = Philosopher::findOrFail($id); // Haal de filosoof op die je wilt bewerken
        return view('edit-filosoof', compact('filosoof')); // Geef de bewerk view terug
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, $id)
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'country' => 'required|string|max:255',
            'birthdate' => 'required|string|max:255', // Geen datumnotatie validatie meer
            'bio' => 'nullable|string',
        ]);

        $philosopher = Philosopher::findOrFail($id);
        $philosopher->update($request->all());

        return redirect()->route('filosofen.index')->with('success', 'Filosoof bijgewerkt!');
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        $filosoof = Philosopher::findOrFail($id); // Haal de filosoof op die je wilt verwijderen
        $filosoof->delete(); // Verwijder de filosoof

        return redirect()->route('filosofen.index')->with('success', 'Filosoof succesvol verwijderd.');
    }
}
