<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>
    <title>Voeg een Nieuwe Filosoof Toe</title>
</head>
<body class="min-h-screen flex flex-col items-center justify-center" style="background-image: url('<?php echo e(asset('images/aristotoles.jpg')); ?>'); background-size: cover; background-repeat: no-repeat;">
<div class="max-w-lg w-full p-6 rounded-lg shadow-md bg-white bg-opacity-80">
    <h1 class="text-3xl font-bold mb-4 text-center">Voeg een Nieuwe Filosoof Toe</h1>

    <form action="<?php echo e(route('filosofen.store')); ?>" method="POST">
        <?php echo csrf_field(); ?> <!-- Zorg ervoor dat je CSRF-token hebt -->

        <div class="mb-4">
            <label for="name" class="block text-gray-700 font-bold mb-2">Naam van de Filosoof:</label>
            <input type="text" name="name" id="name" class="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-400" required>
        </div>

        <div class="mb-4">
            <label for="country" class="block text-gray-700 font-bold mb-2">Land:</label>
            <input type="text" name="country" id="country" class="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-400" required>
        </div>

        <div class="mb-4">
            <label for="birthdate" class="block text-gray-700 font-bold mb-2">Geboortedatum:</label>
            <input type="text" name="birthdate" id="birthdate" class="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-400" placeholder="Bijv. 470 BC" required>
        </div>

        <div class="mb-4">
            <label for="bio" class="block text-gray-700 font-bold mb-2">Biografie:</label>
            <textarea name="bio" id="bio" rows="4" class="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-400" required></textarea>
        </div>

        <div class="text-center">
            <button type="submit" class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded">Voeg Filosoof Toe</button>
        </div>

        <div class="mt-4">
            <a href="<?php echo e(route('filosofen.index')); ?>" class="text-blue-500">Terug naar de lijst van Filosofen</a>
        </div>
    </form>
</div>
</body>
</html>
<?php /**PATH C:\xampp\xampp2\htdocs\Leerjaar2\laravel1\eindopdracht\eindopdracht\resources\views/create-filosoof.blade.php ENDPATH**/ ?>