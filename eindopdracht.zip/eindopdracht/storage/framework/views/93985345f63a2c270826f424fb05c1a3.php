<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>
    <title><?php echo e($filosoof->name); ?> - Informatie</title>
</head>
<body class="min-h-screen flex flex-col items-center justify-center" style="background-image: url('<?php echo e(asset('images/background.avif')); ?>'); background-size: cover; background-repeat: no-repeat;">
<div class="max-w-lg w-full p-6 rounded-lg shadow-md bg-white bg-opacity-80">
    <nav class="mb-4">
        <a href="<?php echo e(route('filosofen.index')); ?>" class="text-blue-500 hover:underline">Home</a>
    </nav>
    <h1 class="text-3xl font-bold mb-4 text-center"><?php echo e($filosoof->name); ?></h1>
    <table class="min-w-full border-collapse border border-gray-300">
        <thead>
        <tr>
            <th class="border border-gray-300 px-4 py-2">Categorie</th>
            <th class="border border-gray-300 px-4 py-2">Informatie</th>
        </tr>
        </thead>
        <tbody>
        <tr>
            <td class="border border-gray-300 px-4 py-2">Land</td>
            <td class="border border-gray-300 px-4 py-2"><?php echo e($filosoof->country); ?></td>
        </tr>
        <tr>
            <td class="border border-gray-300 px-4 py-2">Geboortedatum</td>
            <td class="border border-gray-300 px-4 py-2"><?php echo e($filosoof->birthdate); ?></td>
        </tr>
        <tr>
            <td class="border border-gray-300 px-4 py-2">Biografie</td>
            <td class="border border-gray-300 px-4 py-2"><?php echo e($filosoof->bio); ?></td>
        </tr>
        </tbody>
    </table>
    <div class="mt-6">
        <a href="<?php echo e(route('filosofen.edit', $filosoof->id)); ?>" class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded">
            Bewerk Filosoof
        </a>
    </div>
    <div class="mt-4">
        <a href="<?php echo e(route('filosofen.index')); ?>" class="text-blue-500">Terug naar de lijst van Filosofen</a>
    </div>
</div>
</body>
</html>
<?php /**PATH C:\xampp\xampp2\htdocs\Leerjaar2\laravel1\eindopdracht\eindopdracht\resources\views/filosoof-informatie.blade.php ENDPATH**/ ?>