<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://fonts.googleapis.com/css2?family=Cormorant+Garamond:wght@700&display=swap" rel="stylesheet">
    <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>
    <title>Top Filosofen</title>
</head>
<body class="min-h-screen flex flex-col items-start justify-center pl-20" style="background-image: url('<?php echo e(asset('images/background.avif')); ?>'); background-size: cover; background-repeat: no-repeat;">
<div class="container mx-auto p-6 bg-white bg-opacity-80 rounded-lg shadow-md max-w-md overflow-auto" style="max-height: 350px;">
    <h1 id="top" class="text-3xl font-bold mb-4 text-center" style="font-family: 'Cormorant Garamond', serif;">Lijst van Filosofen</h1>

    <!-- Knop om een nieuwe filosoof toe te voegen -->
    <div class="mt-6 text-center mb-4">
        <a href="<?php echo e(route('filosofen.create')); ?>" class="bg-black hover:bg-gray-800 text-white font-bold py-2 px-4 rounded shadow-lg transition duration-200">
            Maak Nieuwe Filosoof
        </a>
    </div>

    <!-- Succesbericht -->
    <?php if(session('success')): ?>
        <div class="bg-green-500 text-white p-3 rounded mb-4">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <!-- Controleren of er filosofen zijn -->
    <?php if($filosofen->isEmpty()): ?>
        <p class="text-center text-gray-500">Er zijn nog geen filosofen toegevoegd.</p>
    <?php else: ?>
        <div class="overflow-x-auto mt-6">
            <table class="min-w-full bg-white border border-gray-200">
                <thead>
                <tr class="bg-gray-100">
                    <th class="py-2 px-4 border-b text-left text-gray-600">Naam</th>
                    <th class="py-2 px-4 border-b text-left text-gray-600">Acties</th>
                </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $filosofen; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $filosoof): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="hover:bg-gray-50 transition duration-200">
                        <td class="py-2 px-4 border-b">
                            <a href="<?php echo e(route('filosofen.informatie', ['id' => $filosoof->id])); ?>" class="text-blue-600 font-semibold">
                                <?php echo e($filosoof->name); ?>

                            </a>
                        </td>
                        <td class="py-2 px-4 border-b">
                            <div class="flex space-x-2">
                                <a href="<?php echo e(route('filosofen.edit', $filosoof->id)); ?>" class="bg-green-700 hover:bg-green-800 text-white font-bold py-1 px-3 rounded-md shadow-md transition duration-200">
                                    Bewerken
                                </a>

                                <form action="<?php echo e(route('filosofen.destroy', $filosoof->id)); ?>" method="POST" onsubmit="return confirm('Weet je zeker dat je deze filosoof wilt verwijderen?');" style="display:inline;">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="bg-red-700 hover:bg-red-800 text-white font-bold py-1 px-3 rounded-md shadow-md transition duration-200">
                                        Verwijderen
                                    </button>
                                </form>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>

    <!-- Pijl naar boven -->
    <div class="mt-4 text-center">
        <button id="scrollToTop" class="text-blue-600 hover:text-blue-800 flex items-center mx-auto">
            Terug naar boven
        </button>
    </div>
</div>

<script>
    // Scroll naar boven functie
    document.getElementById('scrollToTop').addEventListener('click', function() {
        // Scroll naar het element met ID 'top' (de titel van de tabel)
        const topElement = document.getElementById('top');
        topElement.scrollIntoView({
            behavior: 'smooth'
        });
    });
</script>

</body>
</html>
<?php /**PATH C:\xampp\xampp2\htdocs\Leerjaar2\laravel1\eindopdracht\eindopdracht\resources\views/homepage.blade.php ENDPATH**/ ?>