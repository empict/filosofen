<!DOCTYPE html>
<html lang="nl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css'); ?>
    <title>Bewerk Filosoof</title>
</head>
<body class="min-h-screen flex flex-col items-center justify-center" style="background-image: url('<?php echo e(asset('images/background.avif')); ?>'); background-size: cover; background-repeat: no-repeat;">
<div class="max-w-lg w-full p-6 rounded-lg shadow-md bg-white bg-opacity-80">
    <h1 class="text-3xl font-bold mb-4 text-center">Bewerk Filosoof</h1>

    <?php if($errors->any()): ?>
        <div class="bg-red-500 text-white p-3 rounded mb-4">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <form action="<?php echo e(route('filosofen.update', $filosoof->id)); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <div class="mb-4">
            <label for="name" class="block text-gray-700 font-bold mb-2">Naam van de Filosoof:</label>
            <input type="text" id="name" name="name" value="<?php echo e(old('name', $filosoof->name)); ?>" class="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-400" required>
        </div>

        <div class="mb-4">
            <label for="country" class="block text-gray-700 font-bold mb-2">Land:</label>
            <input type="text" id="country" name="country" value="<?php echo e(old('country', $filosoof->country)); ?>" class="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-400" required>
        </div>

        <div class="mb-4">
            <label for="birthdate" class="block text-gray-700 font-bold mb-2">Geboortedatum:</label>
            <input type="text" id="birthdate" name="birthdate" value="<?php echo e(old('birthdate', $filosoof->birthdate)); ?>" class="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-400" placeholder="Bijv. 470 BC" required>
        </div>

        <div class="mb-4">
            <label for="bio" class="block text-gray-700 font-bold mb-2">Biografie:</label>
            <textarea id="bio" name="bio" rows="4" class="w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-400"><?php echo e(old('bio', $filosoof->bio)); ?></textarea>
        </div>

        <div class="text-center">
            <button type="submit" class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded">Update Filosoof</button>
        </div>

        <div class="mt-4 text-center">
            <a href="<?php echo e(route('filosofen.index')); ?>" class="text-blue-500">Terug naar de lijst van Filosofen</a>
        </div>
    </form>
</div>
</body>
</html>
<?php /**PATH C:\xampp\xampp2\htdocs\Leerjaar2\laravel1\eindopdracht\eindopdracht\resources\views/edit-filosoof.blade.php ENDPATH**/ ?>