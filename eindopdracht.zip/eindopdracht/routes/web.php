<?php

use Illuminate\Support\Facades\Route;
use App\Http\Controllers\PhilosopherController;

Route::get('/filosofen', [PhilosopherController::class, 'index'])->name('filosofen.index');
Route::get('/filosofen/create', [PhilosopherController::class, 'create'])->name('filosofen.create');
Route::post('/filosofen', [PhilosopherController::class, 'store'])->name('filosofen.store');
Route::get('/filosofen/{id}', [PhilosopherController::class, 'show'])->name('filosofen.show');
Route::get('/filosofen/{id}/informatie', [PhilosopherController::class, 'informatie'])->name('filosofen.informatie');
Route::get('/filosofen/{id}/edit', [PhilosopherController::class, 'edit'])->name('filosofen.edit');
Route::put('/filosofen/{id}', [PhilosopherController::class, 'update'])->name('filosofen.update');
Route::delete('/filosofen/{id}', [PhilosopherController::class, 'destroy'])->name('filosofen.destroy');
